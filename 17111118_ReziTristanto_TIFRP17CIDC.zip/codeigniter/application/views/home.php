<!DOCTYPE html>
<html>
<head>
	<title>Sekolah Tinggi Teknologi Bandung</title>
</head>
<body>
<br>
<center><h2>Mata Kuliah Semester 5 | TIF RP 17 CID-C |</h2></center><hr><br>
<center><a href="<?php echo base_url('tugas/tugas');?>">Klik Disini</a></center>
</body>
</html>