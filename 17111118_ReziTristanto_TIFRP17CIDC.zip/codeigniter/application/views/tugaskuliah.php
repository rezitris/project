<!DOCTYPE html>
<html>
<head>
 <title>Sekolah Tinggi Teknologi Bandung</title>
</head>
<body background="image/1.jpg">
 <table width="100%" bgcolor="" border="0" >
<tr>
	<td width="75%" height="410" valign="top"><h2 align="center"><br><font color="black">Nama Mahasiswa</font></br></h2>
	<button><a href="<?php echo base_url('tugas/home');?>">Kembali</a></button>
	
	<br>
	<table border="2" align="center">
		<tr>
			<th bgcolor="yellow" width="150">NPM</th>
			<th bgcolor="yellow" width="150">Nama</th>
			<th bgcolor="yellow" width="150">Kelas</th>
		</tr>
		<tr>
			<td bgcolor="white" align="center">17-111-118</td>
			<td bgcolor="white" align="center">Rezi Tristanto</td>
			<td bgcolor="white" align="center">TIF RP 17 CID-C</td>
		</tr>
	</table><br><br><hr>
	<table width="100%" bgcolor="" border="0" >
<tr>
	<td width="75%" height="410" valign="top"><h2 align="center"><br><font color="black">Mata Kuliah</font></br></h2>
	<br>
	<table border="2" align="center">
		<tr>
		<th bgcolor="yellow" width="20">No</th>
			<th bgcolor="yellow" width="250">Mata Kuliah</th>
			<th bgcolor="yellow" width="250">Dosen</th>
			<th bgcolor="yellow" width="25">SKS</th>
		</tr>
		<tr>
			<td bgcolor="white" align="center">1</td>
			<td bgcolor="white" align="center">Pemrograman Web 2</td>
			<td bgcolor="white" align="center">Andri Nugroho, S.Kom.</td>
			<td bgcolor="white" align="center">3</td>
		</tr>
		<tr>
			<td bgcolor="white" align="center">2</td>
			<td bgcolor="white" align="center">Orkom & Arkom</td>
			<td bgcolor="white" align="center">Imam Yunianto, S.Kom., MM.</td>
			<td bgcolor="white" align="center">3</td>
		</tr>
		<tr>
			<td bgcolor="white" align="center">3</td>
			<td bgcolor="white" align="center">Mobile Programming</td>
			<td bgcolor="white" align="center">Andri Nugraha Ramdhon, S.Kom., M.Kom.</td>
			<td bgcolor="white" align="center">3</td>
		</tr>
		<tr>
			<td bgcolor="white" align="center">4</td>
			<td bgcolor="white" align="center">Desain Kreatif Aplikasi dan Game</td>
			<td bgcolor="white" align="center">Ari Hadhiwibowo, ST., M.Kom.</td>
			<td bgcolor="white" align="center">3</td>
		</tr>
		<tr>
			<td bgcolor="white" align="center">5</td>
			<td bgcolor="white" align="center">Augmented & Virtual Reality</td>
			<td bgcolor="white" align="center">Dhany Indra Gunawan, S.T., M.Kom</td>
			<td bgcolor="white" align="center">3</td>
		</tr>
	</table>
</body>
</html>