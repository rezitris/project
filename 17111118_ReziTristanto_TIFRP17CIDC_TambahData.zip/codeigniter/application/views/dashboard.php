<h3>Data Mahasiswa | Sekolah Tinggi Teknologi Bandung</h3>
<button style="padding: 25px">
<a href="<?php echo base_url('Myadmin/tambahdata');?>">Tambah Data</a>
</button>