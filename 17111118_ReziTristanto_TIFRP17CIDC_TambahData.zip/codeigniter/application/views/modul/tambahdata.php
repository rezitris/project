<br>
<table style="margin:20px auto; padding: 10px" border="5" cellpadding="20px">
	<ul>
		<td>
			<form action="<?php echo base_url('Myadmin/aksi_tambah_data')?>" method="POST" accept-charset="utf-8">

				NPM  :  <input type="number" name="npm" maxlength="12" placeholder="Masukkan NPM" required><br></input><br>
				Nama :  <input type="text" name="nama"  placeholder="Masukkan Nama" required><br></input><br>
				<select name="semester" multiple>
					<option value="">* Pilih Semester</option>
					<?php for ($i=0; $i < 11 ; $i++) { ?>
					<option value="<?php echo $i;?>">Semester<?php echo $i;?>1</option>
					<?php } ?>
				</select>
				<button style="margin: 10px; padding: 15px; height: 50px"  type="submit" value="Submit">Simpan Data</button>
			</form>
		</table>

		<table style="margin:50px auto; padding: 10px" border="5" cellpadding="10px">
			<thead>
				<tr>
					<th bgcolor="yellow">No</th>
					<th bgcolor="yellow" >NPM</th>
					<th bgcolor="yellow">Nama</th>
					<th bgcolor="yellow">Semester</th>
					<th bgcolor="yellow">Opsi</th>
				</tr>
			</thead>
			<tbody>
				<?php 
				$no=1;
				foreach ($tampil as $tpl) {
					echo "<tr><td>".$no."</td>";
					echo "<td>".$tpl->int_npm."</td>";
					echo "<td>".$tpl->str_nama."</td>";
					echo "<td>".$tpl->int_semester."</td>";
					echo "<td>".$tpl->int_semester."</td></tr>";
					$no++;
				}
				 ?>
					</table>
				
			</tbody>
		</table>